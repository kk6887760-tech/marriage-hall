package com.example

import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Log
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ActivityCompat
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  companion object {
    const val NOTIFICATION_PERMISSION_CODE = 7001
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel("booking_alerts", "Booking Alerts", NotificationManager.IMPORTANCE_HIGH)
      getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
    }
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        Surface(
          modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding(),
          color = MaterialTheme.colorScheme.background
        ) {
          MarriageHallAppView()
        }
      }
    }
  }
}

class AndroidAppBridge(
  private val context: Context,
  private val webView: WebView
) {
  private val printWebViews = mutableListOf<WebView>()

  @JavascriptInterface
  fun printDocument(title: String, documentHtml: String, format: String, cssText: String) {
    (context as? Activity)?.runOnUiThread {
      try {
        val printView = WebView(context).apply {
          setBackgroundColor(Color.WHITE)
          settings.javaScriptEnabled = false
          settings.domStorageEnabled = false
          layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
          )
        }
        val printParent = webView.parent as? ViewGroup
        printParent?.addView(printView)
        printWebViews.add(printView)
        printView.webViewClient = object : WebViewClient() {
          override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            printView.postDelayed({
              try {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                val jobName = title.ifBlank { "Marriage_Hall_Document" }
                val printAdapter = printView.createPrintDocumentAdapter(jobName)
                val attributes = PrintAttributes.Builder().build()
                printManager?.print(jobName, printAdapter, attributes)
                printView.postDelayed({
                  printParent?.removeView(printView)
                  printWebViews.remove(printView)
                  printView.destroy()
                }, 120000)
              } catch (e: Exception) {
                printParent?.removeView(printView)
                printWebViews.remove(printView)
                printView.destroy()
                e.printStackTrace()
              }
            }, 250)
          }
        }

        val paperRule = if (format == "thermal") "@page { size: 80mm auto; margin: 2mm; }" else "@page { size: A4; margin: 12mm; }"
        val printHtml = """
          <!DOCTYPE html>
          <html><head>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
              $paperRule
              $cssText
              html, body {
                margin: 0 !important;
                padding: 0 !important;
                width: auto !important;
                height: auto !important;
                min-height: 0 !important;
                overflow: visible !important;
                background: #fff !important;
                color: #000 !important;
              }
              body {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
              }
              .print-root,
              .printable-document {
                display: block !important;
                width: 100% !important;
                max-width: none !important;
                height: auto !important;
                min-height: 0 !important;
                margin: 0 !important;
                padding: 0 !important;
                overflow: visible !important;
                position: static !important;
                background: #fff !important;
                color: #000 !important;
              }
              .no-print,
              .modal-header,
              .print-format-control,
              #printDocumentButton {
                display: none !important;
              }
              * {
                box-sizing: border-box;
                overflow: visible !important;
              }
              img, svg {
                max-width: 100% !important;
              }
            </style>
          </head><body><div class="printable-document">$documentHtml</div></body></html>
        """.trimIndent()
        printView.loadDataWithBaseURL("file:///android_asset/", printHtml, "text/html", "UTF-8", null)
      } catch (e: Exception) {
        e.printStackTrace()
      }
    }
  }

  @JavascriptInterface
  fun shareText(title: String, text: String) {
    (context as? Activity)?.runOnUiThread {
      try {
        val sendIntent = Intent().apply {
          action = Intent.ACTION_SEND
          putExtra(Intent.EXTRA_TITLE, title)
          putExtra(Intent.EXTRA_SUBJECT, title)
          putExtra(Intent.EXTRA_TEXT, text)
          type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, title)
        context.startActivity(shareIntent)
      } catch (e: Exception) {
        e.printStackTrace()
      }
    }
  }

  @JavascriptInterface
  fun shareImage(title: String, base64Image: String) {
    (context as? Activity)?.runOnUiThread {
      try {
        val imageBytes = android.util.Base64.decode(base64Image, android.util.Base64.DEFAULT)
        val sharedDir = java.io.File(context.cacheDir, "shared").apply { mkdirs() }
        val imageFile = java.io.File(sharedDir, "customer-booking-detail.png")
        imageFile.writeBytes(imageBytes)
        val imageUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", imageFile)
        val sendIntent = Intent().apply {
          action = Intent.ACTION_SEND
          putExtra(Intent.EXTRA_STREAM, imageUri)
          putExtra(Intent.EXTRA_TITLE, title)
          type = "image/png"
          addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(sendIntent, title))
      } catch (e: Exception) {
        Log.e("AndroidShare", "Unable to share booking image", e)
      }
    }
  }

  @JavascriptInterface
  fun shareImageToWhatsApp(title: String, base64Image: String, message: String) {
    (context as? Activity)?.runOnUiThread {
      try {
        val imageBytes = android.util.Base64.decode(base64Image, android.util.Base64.DEFAULT)
        val sharedDir = java.io.File(context.cacheDir, "shared").apply { mkdirs() }
        val imageFile = java.io.File(sharedDir, "customer-booking-detail.png")
        imageFile.writeBytes(imageBytes)
        val imageUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", imageFile)
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
          putExtra(Intent.EXTRA_STREAM, imageUri)
          putExtra(Intent.EXTRA_TEXT, message)
          type = "image/png"
          setPackage("com.whatsapp")
          addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
          clipData = ClipData.newRawUri("Booking Card", imageUri)
        }
        context.startActivity(sendIntent)
      } catch (e: Exception) {
        Log.e("WhatsApp", "WhatsApp is not installed or could not be opened", e)
      }
    }
  }

  @JavascriptInterface
  fun requestNotificationPermission() {
    (context as? Activity)?.runOnUiThread {
      if (Build.VERSION.SDK_INT >= 33) {
        ActivityCompat.requestPermissions(context, arrayOf("android.permission.POST_NOTIFICATIONS"), MainActivity.NOTIFICATION_PERMISSION_CODE)
      }
    }
  }

  @JavascriptInterface
  fun showBookingNotification(title: String, text: String): Boolean {
    if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(context, "android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) return false
    if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return false
    (context as? Activity)?.runOnUiThread {
      val notification = NotificationCompat.Builder(context, "booking_alerts")
        .setSmallIcon(com.example.R.mipmap.ic_launcher)
        .setContentTitle(title)
        .setContentText(text)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setAutoCancel(true)
        .build()
      NotificationManagerCompat.from(context).notify(title.hashCode(), notification)
    }
    return true
  }

  @JavascriptInterface
  fun isAndroidApp(): Boolean = true
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MarriageHallAppView() {
  val context = LocalContext.current
  var webViewInstance by remember { mutableStateOf<WebView?>(null) }
  var filePathCallbackRef by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }

  val filePickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    val uri = result.data?.data
    val clipData = result.data?.clipData
    val results: Array<Uri>? = when {
      clipData != null -> Array(clipData.itemCount) { clipData.getItemAt(it).uri }
      uri != null -> arrayOf(uri)
      else -> null
    }
    filePathCallbackRef?.onReceiveValue(results)
    filePathCallbackRef = null
  }

  BackHandler(enabled = true) {
    val webView = webViewInstance
    if (webView != null) {
      webView.evaluateJavascript("window.handleAndroidBackPress ? window.handleAndroidBackPress() : false") { result ->
        if (result != "true") {
          if (webView.canGoBack()) {
            webView.goBack()
          } else {
            (context as? Activity)?.finish()
          }
        }
      }
    } else {
      (context as? Activity)?.finish()
    }
  }

  AndroidView(
    modifier = Modifier
      .fillMaxSize()
      .testTag("marriage_hall_webview"),
    factory = { ctx ->
      WebView(ctx).apply {
        layoutParams = ViewGroup.LayoutParams(
          ViewGroup.LayoutParams.MATCH_PARENT,
          ViewGroup.LayoutParams.MATCH_PARENT
        )

        settings.apply {
          javaScriptEnabled = true
          domStorageEnabled = true
          databaseEnabled = true
          allowFileAccess = true
          allowContentAccess = true
          loadWithOverviewMode = true
          useWideViewPort = true
          cacheMode = WebSettings.LOAD_DEFAULT
          setSupportZoom(true)
          builtInZoomControls = true
          displayZoomControls = false
        }

        addJavascriptInterface(AndroidAppBridge(ctx, this), "AndroidBridge")

        webChromeClient = object : WebChromeClient() {
          override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
            Log.d("WebViewConsole", "${consoleMessage?.message()} (line: ${consoleMessage?.lineNumber()})")
            return true
          }

          override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
          ): Boolean {
            filePathCallbackRef?.onReceiveValue(null)
            filePathCallbackRef = filePathCallback

            val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
              type = "*/*"
            }
            return try {
              filePickerLauncher.launch(intent)
              true
            } catch (e: Exception) {
              filePathCallbackRef?.onReceiveValue(null)
              filePathCallbackRef = null
              false
            }
          }
        }

        webViewClient = object : WebViewClient() {
          override fun onRenderProcessGone(
            view: WebView?,
            detail: RenderProcessGoneDetail?
          ): Boolean {
            Log.w("WebViewRender", "Render process terminated, didCrash: ${detail?.didCrash()}")
            try {
              (view?.parent as? ViewGroup)?.removeView(view)
              view?.destroy()
            } catch (e: Exception) {
              Log.e("WebViewRender", "Error cleaning up WebView", e)
            }
            return true
          }

          override fun shouldOverrideUrlLoading(
            view: WebView?,
            request: WebResourceRequest?
          ): Boolean {
            val url = request?.url?.toString() ?: return false
            if (url.startsWith("file:///android_asset/")) {
              return false
            }
            try {
              val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
              ctx.startActivity(intent)
              return true
            } catch (e: Exception) {
              e.printStackTrace()
            }
            return false
          }
        }

        loadUrl("file:///android_asset/index.html")
        webViewInstance = this
      }
    },
    update = {
      webViewInstance = it
    },
    onRelease = { view ->
      view.stopLoading()
      view.destroy()
    }
  )
}

