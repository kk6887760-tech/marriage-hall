/* Edit only the date below to renew the software license. Format: YYYY-MM-DD */
window.MARRIAGE_HALL_EXPIRY_DATE = '2026-09-12';
